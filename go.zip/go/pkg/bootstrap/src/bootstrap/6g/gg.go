// Do not edit. Bootstrap copy of f:\repo\Go\src\github.com\shrimpy\gostrip\go1.4.2\src\cmd\6g\gg.go

//line f:\repo\Go\src\github.com\shrimpy\gostrip\go1.4.2\src\cmd\6g\gg.go:1
// Copyright 2009 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package main

import "bootstrap/internal/obj/x86"
import "bootstrap/internal/gc"

// Copyright 2009 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

var reg [x86.MAXREG]uint8

var panicdiv *gc.Node

/*
 * cgen.c
 */

/*
 * list.c
 */
