// Do not edit. Bootstrap copy of f:\repo\Go\src\github.com\shrimpy\gostrip\go1.4.2\src\cmd\6l\z.go

//line f:\repo\Go\src\github.com\shrimpy\gostrip\go1.4.2\src\cmd\6l\z.go:1
package main
