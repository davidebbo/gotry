// Do not edit. Bootstrap copy of f:\repo\Go\src\github.com\shrimpy\gostrip\go1.4.2\src\cmd\8g\gg.go

//line f:\repo\Go\src\github.com\shrimpy\gostrip\go1.4.2\src\cmd\8g\gg.go:1
// Copyright 2009 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package main

import "bootstrap/internal/obj/x86"
import "bootstrap/internal/gc"

// TODO(rsc):
//	assume CLD?

// Copyright 2009 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// foptoas flags
const (
	Frev  = 1 << 0
	Fpop  = 1 << 1
	Fpop2 = 1 << 2
)

var reg [x86.MAXREG]uint8

var panicdiv *gc.Node

/*
 * cgen.c
 */

/*
 * list.c
 */
