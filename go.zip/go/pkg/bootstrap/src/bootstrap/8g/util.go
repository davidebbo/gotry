// Do not edit. Bootstrap copy of f:\repo\Go\src\github.com\shrimpy\gostrip\go1.4.2\src\cmd\8g\util.go

//line f:\repo\Go\src\github.com\shrimpy\gostrip\go1.4.2\src\cmd\8g\util.go:1
// Copyright 2015 The Go Authors.  All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package main

func bool2int(b bool) int {
	if b {
		return 1
	}
	return 0
}
