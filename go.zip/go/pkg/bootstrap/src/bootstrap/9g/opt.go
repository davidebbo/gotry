// Do not edit. Bootstrap copy of f:\repo\Go\src\github.com\shrimpy\gostrip\go1.4.2\src\cmd\9g\opt.go

//line f:\repo\Go\src\github.com\shrimpy\gostrip\go1.4.2\src\cmd\9g\opt.go:1
// Copyright 2014 The Go Authors.  All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package main

// Many Power ISA arithmetic and logical instructions come in four
// standard variants.  These bits let us map between variants.
const (
	V_CC = 1 << 0 // xCC (affect CR field 0 flags)
	V_V  = 1 << 1 // xV (affect SO and OV flags)
)
